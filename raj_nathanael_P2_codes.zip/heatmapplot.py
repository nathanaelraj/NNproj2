import math
import tensorflow as tf
import numpy as np
import pylab as plt
import pickle
from itertools import product
import operator
datastore = {(60, 80): {'bestTestAcc': 0.469, 'bestEpoch': 17}, (60, 50): {'bestTestAcc': 0.461, 'bestEpoch': 18}, (80, 40): {'bestTestAcc': 0.46, 'bestEpoch': 14}, (70, 70): {'bestTestAcc': 0.458, 'bestEpoch': 18}, (60, 30): {'bestTestAcc': 0.442, 'bestEpoch': 17}, (40, 40): {'bestTestAcc': 0.461, 'bestEpoch': 16}, (40, 70): {'bestTestAcc': 0.4555, 'bestEpoch': 23}, (80, 30): {'bestTestAcc': 0.453, 'bestEpoch': 16}, (30, 30): {'bestTestAcc': 0.459, 'bestEpoch': 12}, (70, 40): {'bestTestAcc': 0.4505, 'bestEpoch': 18}, (60, 40): {'bestTestAcc': 0.4435, 'bestEpoch': 32}, (70, 30): {'bestTestAcc': 0.4585, 'bestEpoch': 23}, (30, 60): {'bestTestAcc': 0.4625, 'bestEpoch': 18}, (70, 50): {'bestTestAcc': 0.4515, 'bestEpoch': 15}, (50, 60): {'bestTestAcc': 0.447, 'bestEpoch': 13}, (40, 60): {'bestTestAcc': 0.4565, 'bestEpoch': 16}, (50, 40): {'bestTestAcc': 0.465, 'bestEpoch': 21}, (40, 80): {'bestTestAcc': 0.4555, 'bestEpoch': 29},
             (80, 70): {'bestTestAcc': 0.454, 'bestEpoch': 13}, (60, 70): {'bestTestAcc': 0.46, 'bestEpoch': 28}, (30, 70): {'bestTestAcc': 0.466, 'bestEpoch': 37}, (30, 50): {'bestTestAcc': 0.453, 'bestEpoch': 22}, (50, 80): {'bestTestAcc': 0.4705, 'bestEpoch': 15}, (70, 60): {'bestTestAcc': 0.4625, 'bestEpoch': 25}, (60, 60): {'bestTestAcc': 0.461, 'bestEpoch': 16}, (80, 80): {'bestTestAcc': 0.455, 'bestEpoch': 28}, (30, 40): {'bestTestAcc': 0.4715, 'bestEpoch': 33}, (80, 50): {'bestTestAcc': 0.4545, 'bestEpoch': 23}, (40, 30): {'bestTestAcc': 0.4555, 'bestEpoch': 21}, (50, 70): {'bestTestAcc': 0.4615, 'bestEpoch': 16}, (40, 50): {'bestTestAcc': 0.469, 'bestEpoch': 23}, (50, 50): {'bestTestAcc': 0.4585, 'bestEpoch': 27}, (80, 60): {'bestTestAcc': 0.4575, 'bestEpoch': 13}, (50, 30): {'bestTestAcc': 0.453, 'bestEpoch': 16}, (70, 80): {'bestTestAcc': 0.4505, 'bestEpoch': 12}, (30, 80): {'bestTestAcc': 0.4575, 'bestEpoch': 15}}

print(datastore)

index = max(datastore.keys(), key=(lambda key: datastore[key]['bestTestAcc']))
print(index)
print(datastore[index])

for item in datastore:
    print(item, datastore[item]["bestTestAcc"])

space = [30,40,50,60,70,80]

arrayForm = np.zeros(shape = (6,6))

for ind1,pos1 in enumerate(space):
    for ind2,pos2 in enumerate(space):
         arrayForm[ind1][ind2] = datastore[(pos1,pos2)]["bestTestAcc"]

print(arrayForm)
plt.imshow(arrayForm, cmap='hot', interpolation='nearest',extent=[30,100,100,30])
plt.show()
