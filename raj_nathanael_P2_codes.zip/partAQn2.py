#
# Project 2, starter code Part a
#

import math
import tensorflow as tf
import numpy as np
import pylab as plt
import pickle
from itertools import product
import operator

NUM_CLASSES = 10
IMG_SIZE = 32
NUM_CHANNELS = 3
learning_rate = 0.001
epochs = 75
batch_size = 128


seed = 10
np.random.seed(seed)
tf.set_random_seed(seed)

def load_data(file):
    with open(file, 'rb') as fo:
        try:
            samples = pickle.load(fo)
        except UnicodeDecodeError:  #python 3.x
            fo.seek(0)
            samples = pickle.load(fo, encoding='latin1')

    data, labels = samples['data'], samples['labels']

    data = np.array(data, dtype=np.float32)
    labels = np.array(labels, dtype=np.int32)


    labels_ = np.zeros([labels.shape[0], NUM_CLASSES])
    labels_[np.arange(labels.shape[0]), labels-1] = 1

    return data, labels_




def cnn(images,NUM_FM_1, NUM_FM_2):

    images = tf.reshape(images, [-1, IMG_SIZE, IMG_SIZE, NUM_CHANNELS])

    #Conv 1
    W1 = tf.Variable(tf.truncated_normal([9, 9, NUM_CHANNELS, NUM_FM_1], stddev=1.0/np.sqrt(NUM_CHANNELS*9*9)), name='weights_1')
    b1 = tf.Variable(tf.zeros([NUM_FM_1]), name='biases_1')
    print("images",images.get_shape())
    #tf.nn.conv2d(input,filter,strides,padding,)
    conv_1 = tf.nn.relu(tf.nn.conv2d(images, W1, [1, 1, 1, 1], padding='VALID') + b1,name='conv_1')
    pool_1 = tf.nn.max_pool(conv_1, ksize= [1, 2, 2, 1], strides= [1, 2, 2, 1], padding='VALID', name='pool_1')
    print("pool_1",pool_1.get_shape())

    dim_1 = pool_1.get_shape()[1].value * pool_1.get_shape()[2].value * pool_1.get_shape()[3].value
    pool_1_flat = tf.reshape(pool_1, [-1, dim_1])

    #Conv 2
    W2 = tf.Variable(tf.truncated_normal([5, 5, NUM_FM_1, NUM_FM_2], stddev=1.0/np.sqrt(NUM_FM_1*5*5)), name='weights_2')
    b2 = tf.Variable(tf.zeros([NUM_FM_2]), name='biases_2')

    #tf.nn.conv2d(input,filter,strides,padding,)
    conv_2 = tf.nn.relu(tf.nn.conv2d(pool_1, W2, [1, 1, 1, 1], padding='VALID') + b2,name='conv_2')
    pool_2 = tf.nn.max_pool(conv_2, ksize= [1, 2, 2, 1], strides= [1, 2, 2, 1], padding='VALID', name='pool_2')

    dim_2 = pool_2.get_shape()[1].value * pool_2.get_shape()[2].value * pool_2.get_shape()[3].value
    pool_2_flat = tf.reshape(pool_2, [-1, dim_2])
    print("pool_2_flat",pool_2_flat.get_shape())
    print("pool_2_flat",pool_2_flat.get_shape()[1])
    #fully connected
    W3 = tf.Variable(tf.truncated_normal([int(pool_2_flat.get_shape()[1]), 300], stddev=1.0 / np.sqrt(300), dtype=tf.float32), name='weights_3')
    b3 = tf.Variable(tf.zeros([300]), dtype=tf.float32, name='biases_3')
    u = tf.add(tf.matmul(pool_2_flat, W3), b3)
    output_1 = tf.nn.relu(u)
    print("output_1",output_1.get_shape())
    #Softmax
    W4 = tf.Variable(tf.truncated_normal([int(output_1.get_shape()[1]), NUM_CLASSES], stddev=1.0/np.sqrt(NUM_CLASSES)), name='weights_4')
    b4 = tf.Variable(tf.zeros([NUM_CLASSES]), name='biases_4')
    logits = tf.matmul(output_1, W4) + b4

    return logits

def plotActivations(layer,input,sess,x):
    reshapedInput= np.reshape(input,[1,IMG_SIZE*IMG_SIZE*NUM_CHANNELS],order='F')
    #reshapedInput = np.array(input,dtype=np.float32).reshape(1, IMG_SIZE*IMG_SIZE*NUM_CHANNELS)
    print("reshapedInput",reshapedInput.shape)
    units = sess.run(layer,feed_dict={x:reshapedInput})
    numImage = int(layer.get_shape()[3])
    imageSize = int(layer.get_shape()[2])

    plotSize = int(np.sqrt(numImage)) + 1
    for i in range(numImage):
        if i == 1: plt.title(layer.name)
        plt.subplot(plotSize, plotSize, i+1)
        plt.imshow(units[0,:,:,i], interpolation="nearest", cmap="gray")
        plt.axis('off')


    plt.show()
    plt.savefig('./partAQn1b')

def main():

    FM1s = [30,40,50,60,70,80]
    FM2s = [30,40,50,60,70,80]

    dataStore = {}

    for NUM_FM_1, NUM_FM_2 in product(FM1s, FM2s):


        tf.reset_default_graph()
        trainX, trainY = load_data('data_batch_1')
        print(type(trainX))
        print(trainX.shape, trainY.shape)

        testX, testY = load_data('test_batch_trim')
        print(testX.shape, testY.shape)
        smallSet = 5000
        #small dataset first
        N = len(trainX)
        idx = np.arange(N)
        np.random.shuffle(idx)
        trainX, trainY = trainX[idx], trainY[idx]
        trainX, trainY = trainX[:smallSet,:], trainY[:smallSet,:]
        print(trainX.shape, trainY.shape)
        print(testX.shape, testY.shape)

        testX = (testX - np.min(trainX, axis = 0))/np.max(trainX, axis = 0)

        trainX = (trainX - np.min(trainX, axis = 0))/np.max(trainX, axis = 0)

        # Create the model
        x = tf.placeholder(tf.float32, [None, IMG_SIZE*IMG_SIZE*NUM_CHANNELS])
        y_ = tf.placeholder(tf.float32, [None, NUM_CLASSES])


        logits = cnn(x,NUM_FM_1, NUM_FM_2)

        cross_entropy = tf.nn.softmax_cross_entropy_with_logits_v2(labels=y_, logits=logits)
        loss = tf.reduce_mean(cross_entropy)

        correct_prediction = tf.cast(tf.equal(tf.argmax(logits, 1), tf.argmax(y_, 1)), tf.float32)
        accuracy = tf.reduce_mean(correct_prediction)

        train_step = tf.train.AdamOptimizer(learning_rate).minimize(loss)

        N = len(trainX)
        idx = np.arange(N)

        dataStore[(NUM_FM_1, NUM_FM_2)] = {}

        bestTestAcc = 0
        bestEpoch = 0

        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())

            for e in range(epochs):
                np.random.shuffle(idx)
                trainX, trainY = trainX[idx], trainY[idx]

                for start, end in zip(range(0, trainX.shape[0], batch_size), range(batch_size, trainX.shape[0], batch_size)):
                    sess.run([train_step, loss],feed_dict={x: trainX[start:end], y_: trainY[start:end]})


                loss_ = loss.eval({x: trainX, y_: trainY})
                acc = accuracy.eval(feed_dict={x: testX, y_: testY})
                if acc > bestTestAcc:
                    bestTestAcc = acc
                    bestEpoch = e


                print('epoch', e, 'entropy', loss_)

        print("NUM_FM_1", NUM_FM_1, "NUM_FM_2",NUM_FM_2,"bestTestAcc",bestTestAcc,"bestEpoch",bestEpoch)
        dataStore[(NUM_FM_1, NUM_FM_2)]["bestTestAcc"] = bestTestAcc
        dataStore[(NUM_FM_1, NUM_FM_2)]["bestEpoch"] = bestEpoch

    print(dataStore)
    index = max(dataStore.keys(), key=(lambda key: dataStore[key]['bestTestAcc']))
    print("index",index)
    print(dataStore[index])


if __name__ == '__main__':
  main()
